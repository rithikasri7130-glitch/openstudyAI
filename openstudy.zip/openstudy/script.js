const $ = (id) => document.getElementById(id);
const pdfInput = $("pdf");
const filenameEl = $("filename");
const questionEl = $("question");
const questionLabel = document.querySelector('label[for="question"]');
const responseEl = $("response");
const statusEl = $("status");
const headingEl = $("heading");
const actionButtons = [$("ask"), $("summary"), $("quiz")];
const navButtons = document.querySelectorAll(".nav");

const MODES = {
  ask: "Ask your AI tutor",
  summary: "Summarize your notes",
  quiz: "Generate a quiz",
};

let busy = false;

// ---------- helpers ----------
function setBusy(value) {
  busy = value;
  actionButtons.forEach((b) => (b.disabled = value));
}

function setMessage(text, isError = false) {
  responseEl.classList.remove("rendered");
  responseEl.classList.toggle("error", isError);
  responseEl.textContent = text;
}

function setMode(mode) {
  headingEl.textContent = MODES[mode];
  navButtons.forEach((n) => n.classList.toggle("active", n.dataset.mode === mode));
  const showQuestion = mode === "ask";
  questionEl.hidden = !showQuestion;
  if (questionLabel) questionLabel.hidden = !showQuestion;
}

// Safe mini-markdown: **bold**, "- " / "1. " lists, paragraphs. Uses textContent only (no XSS).
function addInline(parent, text) {
  text.split(/(\*\*[^*]+\*\*)/g).forEach((part) => {
    if (!part) return;
    if (/^\*\*[^*]+\*\*$/.test(part)) {
      const s = document.createElement("strong");
      s.textContent = part.slice(2, -2);
      parent.appendChild(s);
    } else {
      parent.appendChild(document.createTextNode(part));
    }
  });
}

function renderText(text) {
  const frag = document.createDocumentFragment();
  let list = null;
  text.split("\n").forEach((raw) => {
    const line = raw.trim();
    const m = line.match(/^(?:[-*•]|\d+[.)])\s+(.*)$/);
    if (m) {
      if (!list) {
        list = document.createElement(/^\d/.test(line) ? "ol" : "ul");
        frag.appendChild(list);
      }
      const li = document.createElement("li");
      addInline(li, m[1]);
      list.appendChild(li);
    } else {
      list = null;
      if (!line) return;
      const p = document.createElement("p");
      addInline(p, line);
      frag.appendChild(p);
    }
  });
  responseEl.classList.add("rendered");
  responseEl.classList.remove("error");
  responseEl.replaceChildren(frag);
}

function renderQuiz(items) {
  const wrap = document.createElement("div");
  wrap.className = "quiz";
  const score = document.createElement("p");
  score.className = "quiz-score";
  score.textContent = "Answer each question. Score will appear at the end.";
  let answered = 0;
  let correct = 0;

  items.forEach((q, qi) => {
    const box = document.createElement("div");
    box.className = "quiz-q";
    const title = document.createElement("h4");
    title.textContent = `${qi + 1}. ${q.question}`;
    box.appendChild(title);
    const optButtons = [];
    q.options.forEach((opt, oi) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "quiz-opt";
      b.textContent = `${String.fromCharCode(65 + oi)}. ${opt}`;
      b.addEventListener("click", () => {
        optButtons.forEach((o) => (o.disabled = true));
        if (oi === q.answer_index) {
          b.classList.add("right");
          correct++;
        } else {
          b.classList.add("wrong");
          optButtons[q.answer_index].classList.add("right");
        }
        answered++;
        if (answered === items.length) {
          score.textContent = `Score: ${correct} / ${items.length}`;
        }
      });
      optButtons.push(b);
      box.appendChild(b);
    });
    wrap.appendChild(box);
  });

  wrap.appendChild(score);
  responseEl.classList.add("rendered");
  responseEl.classList.remove("error");
  responseEl.replaceChildren(wrap);
}

// ---------- main action ----------
async function send(mode) {
  if (busy) return;
  setMode(mode);

  const question = questionEl.value.trim();
  const file = pdfInput.files[0];

  if (mode === "ask" && !question) {
    setMessage("Question type pannu.", true);
    return;
  }
  if (mode !== "ask" && !file) {
    setMessage("Mudhalla oru PDF upload pannu (Step 01).", true);
    return;
  }

  setBusy(true);
  setMessage("AI yosikkuthu... wait pannu ⏳");

  const fd = new FormData();
  fd.append("mode", mode);
  fd.append("question", question);
  if (file) fd.append("pdf", file);

  try {
    const res = await fetch("/api/study", { method: "POST", body: fd });
    const type = res.headers.get("content-type") || "";

    if (type.includes("application/json")) {
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || "Server error");
      if (data.quiz) renderQuiz(data.quiz);
      else setMessage(data.answer || "No response");
      return;
    }
    if (!res.ok) throw new Error("Server error " + res.status);

    // streamed text: show words as the model writes them
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let text = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      text += decoder.decode(value, { stream: true });
      renderText(text);
    }
    text += decoder.decode();
    if (text.trim()) renderText(text);
    else setMessage("No response", true);
  } catch (e) {
    setMessage(e.message, true);
  } finally {
    setBusy(false);
  }
}

// ---------- events ----------
pdfInput.addEventListener("change", () => {
  filenameEl.textContent = pdfInput.files[0]
    ? "Selected: " + pdfInput.files[0].name
    : "No file selected";
});

$("ask").addEventListener("click", () => send("ask"));
$("summary").addEventListener("click", () => send("summary"));
$("quiz").addEventListener("click", () => send("quiz"));

navButtons.forEach((n) =>
  n.addEventListener("click", () => {
    const mode = n.dataset.mode;
    if (mode === "ask") {
      setMode("ask");
      questionEl.focus();
    } else {
      send(mode);
    }
  })
);

questionEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send("ask");
});

// ---------- AI engine status ----------
async function checkHealth() {
  try {
    const h = await (await fetch("/api/health")).json();
    if (!h.ollama) {
      statusEl.textContent = "⚠ Ollama run aagala. Terminal-la 'ollama serve' pannu.";
      statusEl.className = "status bad";
    } else if (!h.model_ready) {
      statusEl.textContent = `⚠ Model illa. Terminal-la: ollama pull ${h.model}`;
      statusEl.className = "status bad";
    } else {
      statusEl.textContent = `● AI ready (${h.model})`;
      statusEl.className = "status ok";
    }
  } catch (e) {
    statusEl.textContent = "⚠ Flask server-a reach panna mudiyala.";
    statusEl.className = "status bad";
  }
}

setMode("ask");
checkHealth();
