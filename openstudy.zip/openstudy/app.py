"""OpenStudy AI - Flask backend. Local AI via Ollama, PDF text via PyMuPDF."""
import hashlib
import json
import math
import os
import re
from collections import Counter, OrderedDict

try:
    import pymupdf as fitz  # PyMuPDF (new name)
except ImportError:  # older PyMuPDF
    import fitz
import requests
from flask import Flask, Response, jsonify, request, send_from_directory, stream_with_context

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL = os.environ.get("OPENSTUDY_MODEL", "llama3.2:1b")
OLLAMA = os.environ.get("OPENSTUDY_OLLAMA_URL", "http://localhost:11434").rstrip("/")

NUM_CTX = 4096          # context window sent to Ollama (default 2048 is too small)
CHUNK_SIZE = 900        # characters per note chunk
ASK_BUDGET = 3500       # characters of notes sent for a question
SUMMARY_BUDGET = 7000   # characters of notes sent for summary / quiz
QUIZ_COUNT = 5

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB upload limit

SYSTEM = (
    "You are OpenStudy, a friendly study tutor for college students. "
    "Use simple, clear English. When notes are given, base your answer ONLY on the notes. "
    "If the notes do not contain the answer, say so plainly instead of guessing."
)

QUIZ_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {"type": "array", "items": {"type": "string"}},
                    "answer_index": {"type": "integer"},
                },
                "required": ["question", "options", "answer_index"],
            },
        }
    },
    "required": ["questions"],
}


class UserError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


# ------------------------------------------------------------------ PDF -> chunks
_cache = OrderedDict()  # sha1(pdf bytes) -> chunks (so repeat questions skip re-parsing)

STOP = set(
    "a an the is are was were be been of to in on at for and or but if then so as by with from "
    "this that these those it its what which who whom how why when where do does did can could "
    "should would will shall may might about into than also me my you your i we they he she "
    "explain tell give define describe please".split()
)


def split_long(paragraph, size):
    parts, cur = [], ""
    for sentence in re.split(r"(?<=[.!?])\s+|\n", paragraph):
        while len(sentence) > size:
            if cur:
                parts.append(cur)
                cur = ""
            parts.append(sentence[:size])
            sentence = sentence[size:]
        if cur and len(cur) + len(sentence) + 1 > size:
            parts.append(cur)
            cur = sentence
        else:
            cur = (cur + " " + sentence).strip()
    if cur:
        parts.append(cur)
    return parts


def chunk_text(text):
    text = text.replace("\r", "")
    text = re.sub(r"[ \t]+", " ", text)
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if len(paragraphs) <= 1:  # PDF with no blank lines: treat every line as soft-wrapped text
        paragraphs = [" ".join(text.split())] if text.strip() else []
    pieces = []
    for p in paragraphs:
        p = " ".join(p.split())
        pieces.extend(split_long(p, CHUNK_SIZE) if len(p) > CHUNK_SIZE else [p])
    chunks, cur = [], ""
    for piece in pieces:
        if cur and len(cur) + len(piece) + 1 > CHUNK_SIZE:
            chunks.append(cur)
            cur = piece
        else:
            cur = (cur + " " + piece).strip()
    if cur:
        chunks.append(cur)
    return chunks


def load_notes(upload):
    raw = upload.read()
    if not raw:
        raise UserError("PDF empty ah irukku. Vera file try pannu.")
    key = hashlib.sha1(raw).hexdigest()
    if key in _cache:
        _cache.move_to_end(key)
        return _cache[key]
    try:
        doc = fitz.open(stream=raw, filetype="pdf")
    except Exception:
        raise UserError("Idhu valid PDF file alla.")
    if doc.needs_pass:
        doc.close()
        raise UserError("PDF password-protected. Password remove panni upload pannu.")
    text = "\n\n".join(page.get_text() for page in doc)
    doc.close()
    chunks = chunk_text(text)
    if not chunks:
        raise UserError(
            "PDF-la text kedaikkala. Scanned image PDF-a irukkalaam. Text irukkura PDF upload pannu."
        )
    _cache[key] = chunks
    while len(_cache) > 8:
        _cache.popitem(last=False)
    return chunks


# ------------------------------------------------------------------ choosing what to send
def tokens(s):
    out = []
    for w in re.findall(r"[a-z0-9]+", s.lower()):
        if w in STOP or len(w) < 2:
            continue
        if len(w) > 3 and w.endswith("s"):
            w = w[:-1]
        out.append(w)
    return out


def take_head(chunks, budget):
    out, used = [], 0
    for c in chunks:
        if out and used + len(c) > budget:
            break
        out.append(c)
        used += len(c)
    return out


def select_for_question(chunks, question, budget=ASK_BUDGET):
    """Keyword (TF-IDF style) retrieval so the WHOLE pdf is searchable, not just the first pages."""
    q = set(tokens(question))
    if not q:
        return take_head(chunks, budget)
    docs = [Counter(tokens(c)) for c in chunks]
    n = len(chunks)
    df = {t: sum(1 for d in docs if t in d) for t in q}
    scored = []
    for i, d in enumerate(docs):
        score = sum((1 + math.log(d[t])) * math.log(1 + n / df[t]) for t in q if d.get(t))
        if score > 0:
            scored.append((score, i))
    if not scored:
        return take_head(chunks, budget)
    scored.sort(reverse=True)
    picked, used = [], 0
    for _, i in scored:
        if picked and used + len(chunks[i]) > budget:
            continue
        picked.append(i)
        used += len(chunks[i])
    return [chunks[i] for i in sorted(picked)]


def sample_evenly(chunks, budget=SUMMARY_BUDGET):
    """Spread the budget across the whole document (start, middle, end)."""
    total = sum(len(c) for c in chunks)
    if total <= budget:
        return chunks
    k = max(1, int(budget // (total / len(chunks))))
    step = len(chunks) / k
    out, used = [], 0
    for i in sorted({int(j * step) for j in range(k)}):
        if out and used + len(chunks[i]) > budget:
            break
        out.append(chunks[i])
        used += len(chunks[i])
    return out


# ------------------------------------------------------------------ Ollama
def ollama_chat(messages, stream, fmt=None):
    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": stream,
        "options": {"num_ctx": NUM_CTX, "temperature": 0.3},
    }
    if fmt:
        payload["format"] = fmt
    try:
        r = requests.post(f"{OLLAMA}/api/chat", json=payload, stream=stream, timeout=(5, 300))
    except requests.exceptions.ConnectionError:
        raise UserError("Ollama run aagala. Terminal-la 'ollama serve' pannu.", 503)
    except requests.exceptions.Timeout:
        raise UserError("Ollama romba neram edukkuthu (timeout). Marupadiyum try pannu.", 504)
    if r.status_code != 200:
        try:
            msg = r.json().get("error", r.text)
        except Exception:
            msg = r.text
        r.close()
        if r.status_code == 404 and "not found" in msg.lower():
            raise UserError(f"Model '{MODEL}' illa. Terminal-la: ollama pull {MODEL}", 503)
        raise UserError(f"Ollama error: {msg}", 502)
    return r


def stream_tokens(r, prefix=""):
    try:
        if prefix:
            yield prefix
        for line in r.iter_lines():
            if not line:
                continue
            data = json.loads(line)
            if "error" in data:
                yield "\n\n⚠ " + str(data["error"])
                return
            piece = data.get("message", {}).get("content", "")
            if piece:
                yield piece
            if data.get("done"):
                return
    except requests.exceptions.RequestException as e:
        yield f"\n\n⚠ Connection cut aachu: {e}"
    finally:
        r.close()


def parse_quiz(content):
    try:
        data = json.loads(content)
    except Exception:
        return []
    items = data.get("questions", []) if isinstance(data, dict) else data
    if not isinstance(items, list):
        return []
    quiz = []
    for it in items:
        if not isinstance(it, dict):
            continue
        q = str(it.get("question", "")).strip()
        opts = it.get("options")
        ans = it.get("answer_index")
        if not q or not isinstance(opts, list) or len(opts) != 4:
            continue
        opts = [str(o).strip() for o in opts]
        if not all(opts) or len(set(o.lower() for o in opts)) != 4:
            continue
        if isinstance(ans, bool) or not isinstance(ans, int) or not 0 <= ans <= 3:
            continue
        quiz.append({"question": q, "options": opts, "answer_index": ans})
    return quiz[:QUIZ_COUNT]


# ------------------------------------------------------------------ routes
@app.route("/")
def home():
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/<path:filename>")
def frontend_files(filename):
    if filename in ("style.css", "script.js"):
        return send_from_directory(BASE_DIR, filename)
    return jsonify({"error": "File not found"}), 404


@app.route("/api/health")
def health():
    try:
        r = requests.get(f"{OLLAMA}/api/tags", timeout=3)
        names = [m.get("name", "") for m in r.json().get("models", [])]
        ready = any(n == MODEL or n.startswith(MODEL + ":") for n in names)
        return jsonify({"ollama": True, "model": MODEL, "model_ready": ready})
    except Exception:
        return jsonify({"ollama": False, "model": MODEL, "model_ready": False})


@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "PDF romba periya (max 20 MB)."}), 413


@app.route("/api/study", methods=["POST"])
def study():
    try:
        mode = request.form.get("mode", "ask")
        question = request.form.get("question", "").strip()
        upload = request.files.get("pdf")
        if mode not in ("ask", "summary", "quiz"):
            raise UserError("Unknown mode.")

        chunks = load_notes(upload) if upload else None

        if mode == "ask":
            if not question:
                raise UserError("Question type pannu.")
            if chunks:
                excerpts = "\n\n".join(select_for_question(chunks, question))
                user = (
                    f'Notes (excerpts):\n"""\n{excerpts}\n"""\n\nQuestion: {question}\n\n'
                    "Answer using only the notes. Keep it short and clear."
                )
                prefix = ""
            else:
                user = f"Question: {question}\n\nAnswer simply and briefly."
                prefix = "(PDF upload pannala, so idhu general answer.)\n\n"
            r = ollama_chat([{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}], True)
            return stream_response(r, prefix)

        if not chunks:
            raise UserError("Summary / Quiz-ku mudhalla PDF upload pannu.")
        notes = "\n\n".join(sample_evenly(chunks))

        if mode == "summary":
            user = (
                f'Notes:\n"""\n{notes}\n"""\n\n'
                "Summarize these notes in 6 to 10 short bullet points. Start every bullet with '- '. "
                "Finish with one line starting 'Key takeaway:'."
            )
            r = ollama_chat([{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}], True)
            return stream_response(r)

        user = (
            f'Notes:\n"""\n{notes}\n"""\n\n'
            f"Create exactly {QUIZ_COUNT} multiple-choice questions that can be answered from these notes. "
            'Reply as JSON: {"questions":[{"question":"...","options":["A","B","C","D"],"answer_index":0}]}. '
            "Each question has exactly 4 different options; answer_index (0-3) is the correct option."
        )
        msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]
        try:
            r = ollama_chat(msgs, False, QUIZ_SCHEMA)
        except UserError as e:  # older Ollama versions only know format="json"
            if "format" not in e.message.lower():
                raise
            r = ollama_chat(msgs, False, "json")
        quiz = parse_quiz(r.json().get("message", {}).get("content", ""))
        if not quiz:
            raise UserError("Quiz generate aagala (small model). Marupadiyum 'Make a quiz' click pannu.", 502)
        return jsonify({"quiz": quiz})

    except UserError as e:
        return jsonify({"error": e.message}), e.status
    except Exception as e:  # last resort so the UI always gets JSON
        return jsonify({"error": f"Server error: {e}"}), 500


def stream_response(r, prefix=""):
    resp = Response(stream_with_context(stream_tokens(r, prefix)), mimetype="text/plain")
    resp.headers["Cache-Control"] = "no-cache"
    resp.headers["X-Accel-Buffering"] = "no"
    return resp


if __name__ == "__main__":
    app.run(port=5000, debug=os.environ.get("FLASK_DEBUG", "1") == "1")
