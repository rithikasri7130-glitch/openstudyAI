# OpenStudy AI

Upload a PDF, ask questions, get a summary, or take an auto-made quiz. Runs 100% locally with Ollama.

## Run
1. Install Ollama and pull the model:  `ollama pull llama3.2:1b`
2. In this folder:
   ```
   pip install -r requirements.txt
   python app.py
   ```
3. Open http://localhost:5000  (status line shows "AI ready" when Ollama + model are found)

Optional: `OPENSTUDY_MODEL=llama3.2:3b python app.py` for a smarter model (needs more RAM).

Files must be named exactly: app.py, index.html, style.css, script.js (same folder).
